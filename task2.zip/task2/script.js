let slideIndex = 0;
showSlides(slideIndex);

function moveSlide(n) {
    showSlides(slideIndex += n);
}

function showSlides(n) {
    let slides = document.querySelectorAll(".slide");
    if (n >= slides.length) slideIndex = 0;
    if (n < 0) slideIndex = slides.length - 1;
    slides.forEach(slide => slide.classList.remove("active"));
    slides[slideIndex].classList.add("active");
}

function openModal(id) {
    document.getElementById(id).style.display = "block";
}

function closeModal(id) {
    document.getElementById(id).style.display = "none";
}

const priceRange = document.getElementById('priceRange');
const priceValue = document.getElementById('priceValue');
priceRange.oninput = function() {
    priceValue.textContent = this.value;
};

const accordions = document.querySelectorAll('.accordion-header');
accordions.forEach(accordion => {
    accordion.addEventListener('click', () => {
        const body = accordion.nextElementSibling;
        body.style.display = body.style.display === 'block' ? 'none' : 'block';
    });
});
