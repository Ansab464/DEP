document.getElementById('reservationForm').addEventListener('submit', function (event) {
    event.preventDefault();
    validateForm();
});

function validateForm() {
    let isValid = true;

    const name = document.getElementById('name');
    const nameError = document.getElementById('nameError');
    if (name.value.trim() === '') {
        nameError.textContent = 'Name is required';
        nameError.style.display = 'block';
        isValid = false;
    } else {
        nameError.style.display = 'none';
    }

    const email = document.getElementById('email');
    const emailError = document.getElementById('emailError');
    const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!emailPattern.test(email.value)) {
        emailError.textContent = 'Please enter a valid email address';
        emailError.style.display = 'block';
        isValid = false;
    } else {
        emailError.style.display = 'none';
    }

    const phone = document.getElementById('phone');
    const phoneError = document.getElementById('phoneError');
    const phonePattern = /^[0-9]{10}$/;
    if (!phonePattern.test(phone.value)) {
        phoneError.textContent = 'Phone number must be 10 digits';
        phoneError.style.display = 'block';
        isValid = false;
    } else {
        phoneError.style.display = 'none';
    }

    const guests = document.getElementById('guests');
    const guestsError = document.getElementById('guestsError');
    if (guests.value < 1 || guests.value > 10) {
        guestsError.textContent = 'Number of guests must be between 1 and 10';
        guestsError.style.display = 'block';
        isValid = false;
    } else {
        guestsError.style.display = 'none';
    }

    const date = document.getElementById('date');
    const dateError = document.getElementById('dateError');
    if (date.value === '') {
        dateError.textContent = 'Please select a reservation date';
        dateError.style.display = 'block';
        isValid = false;
    } else {
        dateError.style.display = 'none';
    }

    if (isValid) {
        alert('Reservation successfully submitted!');
        document.getElementById('reservationForm').reset();
    }
}
