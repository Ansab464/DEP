// Lazy loading for images
document.addEventListener("DOMContentLoaded", function() {
    const lazyImages = document.querySelectorAll(".lazy");

    lazyImages.forEach(img => {
        img.src = img.dataset.src;
    });
});
